import java.util.*;


public class TimeGenerator {
    long startMs;
    long endMs;
    int count;
    Random r = new Random();

    public TimeGenerator(long startMs, long endMs, int count) {
        this.startMs = startMs;
        this.endMs = endMs;
        this.count = count;
    }

//    public ArrayList<Long> getTimes() {
//        ArrayList<Long> longs = new ArrayList<>(count * 3);
//        for (int i = 0; i < count * 4; i++) {
//            longs.add(randomBetween());
//        }
//        int i = 0;
//        double dilnyk = 60 * 1000 * 60 * 24;
//        int size = count * 4;
//        while (size > count) {
//            if (i >= longs.size()) {
//                i = 0;
////                System.out.println("size"+longs.size());
//            }
//            Double test = r.nextDouble() - 0.4;
//            Double q1 = Double.valueOf((Math.abs(longs.get(i) % dilnyk - dilnyk)) / dilnyk); //posible to do les math  (почленно розділити)
//            if (test < q1) {
//                longs.remove(i);
//                size--;
//            }
//
//            i++;
//        }
//        System.err.println("do less math");
//        Collections.sort(longs);
//        return longs;
//    }

//    public ArrayList<Long> getTimes() {
//        ArrayList<Long> longs = new ArrayList<>();
//        LinkedList<Long> newTimes = new LinkedList();
//        for (int i = 0; i < count *10; i++) {
//            longs.add(randomBetween());
//        }
//        int i = 0;
//        int size = count * 10;
//        int all = 0;
//        double dilnyk = 10 * 60 * 1000 * 60;
//        while (true) {
//            if(all>=count) break;
//            if (i>=size) {
//                i=0;
//                System.out.println("size" + newTimes.size());
////                longs = new ArrayList(newTimes);
////                newTimes = new LinkedList();
////                i = 0;
//////                System.out.println("size" + longs.size());
//            }
//            Double test = r.nextDouble() +0.2;
//            Long minest = longs.get(i) % (1000  * 60 * 24*60);
//            Double q1 = Double.valueOf((Math.abs(minest - dilnyk)) / (dilnyk)); //posible to do les math  (почленно розділити)
//            if (test >q1) {
//
//                newTimes.add(longs.get(i));
//                all++;
//            }
////            System.out.println(i);
//            i++;
//        }
//        System.out.println(newTimes.size());
//        System.err.println("do less math");
//        Collections.sort(newTimes);
//        return new ArrayList<>(newTimes);
//    }

// last version
    public ArrayList<Long> getTimes() {
        ArrayList<Long> longs = new ArrayList<>();
        LinkedList<Long> newTimes = new LinkedList();
        for (int i = 0; i < count * 10; i++) {
            longs.add(randomBetween());
        }
        int i = 0;
        int size = count * 10;
        int all = 0;
        double dilnyk = 10 * 60 * 1000 * 60;
        while (true) {
            if (all >= count) break;
            if (i >= size) {
                i = 0;
                System.out.println("size" + newTimes.size());
// longs = new ArrayList(newTimes);
// newTimes = new LinkedList();
// i = 0;
//// System.out.println("size" + longs.size());
            }
            Double test = r.nextDouble() + 0.2;
            Long minest = longs.get(i) % (1000 * 60 * 24 * 60);
            Double q1 = Double.valueOf((Math.abs(minest - dilnyk)) / (dilnyk)); //posible to do les math (почленно розділити)
            if (test > q1) {

                newTimes.add(longs.get(i));
                all++;
            }
// System.out.println(i);
            i++;
        }
        System.out.println(newTimes.size());
        System.err.println("do less math");
        Collections.sort(newTimes);
        return new ArrayList<>(newTimes);
    }

    private long randomBetween() {
        long resvult = (endMs - (long) (Math.random() * (endMs - startMs)));
//        System.out.println( resvult);
        return resvult;
    }
}
/* if (i >= longs.size()) {
                System.out.println("size" + newTimes.size());
                longs = new ArrayList(newTimes);
                newTimes = new LinkedList();
                i = 0;
//                System.out.println("size" + longs.size());
            }
            Double test = r.nextDouble() - 0.65;
            Long minest = longs.get(i) % (1000 * 60 * 60 * 24);
            Double q1 = Double.valueOf(Math.abs(minest - dilnyk) / dilnyk); //posible to do les math  (почленно розділити)
            if (test > q1) {
                newTimes.add(longs.get(i));
                all++;
            }
//            System.out.println(i);
            i++;*/