import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by Oleksandr_Shainoga on 8/7/2017.
 */

/*
%h – The IP address of the client.
%l – The identity of the client determined by identd on the client’s machine. Will return a hyphen (-) if this information is not available.
%u – The userid of the client if the request was authenticated.
%t – The time that the request was received.
\"%r\" – The request line that includes the HTTP method used, the requested resource path, and the HTTP protocol that the client used.
%>s – The status code that the server sends back to the client.
%b – The size of the object requested.
 */
public class TestGenerator {
    int logKount;
    long startMs;
    long endMS;
    ArrayList<Long> times;

    Integer status[] = {100, 101, 102, 200, 201, 202, 203, 204, 300, 301, 302, 303, 307, 400, 404, 401, 402, 405, 500, 501, 502, 503};
    int amountOfStatus=4;

    public TestGenerator(int logKount, long startMs, long endMS) {
        this.logKount = logKount;
        this.startMs = startMs;
        this.endMS = endMS;
        TimeGenerator timeGenerator = new TimeGenerator(startMs, endMS, logKount);
        times = timeGenerator.getTimes();

    }

    public String gen() {
        String ip = ipGen();
        String l = ident();
        String userId = userId();
        String t = time();
        String r = genHttp();
        String s = statusCode();
        String b = size();
        return ip + " " + l + " " + userId + " " + t + " " + r + " " + s + " " + b;
    }

    private String ipGen() {
        return "127.0.0.1";
    }

    private String ident() {
        return "-";
    }

    private String userId() {
        return String.valueOf((int) (Math.random() * 1000));
    }

    int timeIndex = 0;

    private String time() {
        SimpleDateFormat sdf = new SimpleDateFormat("[dd/MM/yyyy:HH:mm:ss Z]");
//        System.out.println("time =" +times.get(timeIndex));
        String date = sdf.format(times.get(timeIndex));
        timeIndex++;
        return date;
    }


    private String genHttp() {
        String out = "\"";
        out += "GET /sample-image.png HTTP/2\"";
        return out;
    }

    private String statusCode() {
        return status[(int) (Math.random() *amountOfStatus)]+"";
    }

    private String size() {
        return String.valueOf((int) (Math.random() * 10000));
    }
}
