import com.sun.org.apache.xalan.internal.xsltc.compiler.util.TestGenerator;

import java.time.Period;
import java.util.*;

/**
 * Created by Oleksandr_Shainoga on 8/8/2017.
 */
public class rozpodilDaty {
    public static void main(String[] args) {

        Date d=new Date();
        Date d1=new Date(2017-1900,7,5);
        TimeGenerator t=new TimeGenerator(d1.getTime(),d.getTime(),100000);
       ArrayList<Long> l= t.getTimes();
        System.out.println(d);
        System.out.println(d1);
       int totalHours= (int) ((d.getTime()-d1.getTime())/(1000*60*60));
        System.out.println(totalHours);
        int r[]=new int[totalHours+1];
        for (int i = 0; i <l.size() ; i++) {
            long secs = (l.get(i) - d1.getTime()) / 1000;
            int hours = (int) (secs / 3600);
            r[hours]++;
        }
        for (int i = 0; i <r.length ; i++) {
            System.out.println(r[i]);
        }
    }
}
