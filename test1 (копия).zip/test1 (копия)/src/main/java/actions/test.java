package actions;


import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Created by Oleksandr_Shainoga on 8/9/2017.
 */
public class test {
    public static void main(String[] args) throws IOException {
        byte[] jsonData = Files.readAllBytes(Paths.get("graph.txt"));
//        "graph.txt"
        ObjectMapper objectMapper = new ObjectMapper();

        //convert json string to object
        Action emp = objectMapper.readValue(jsonData, Action.class);

        System.out.println("Employee Object\n"+emp);

//        //convert Object to json string
//        Action emp1 = createEmployee();
//        //configure Object mapper for pretty print
//        objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
//
//        //writing to console, can write to any output stream such as file
//        StringWriter stringEmp = new StringWriter();
//        objectMapper.writeValue(stringEmp, emp1);
//        System.out.println("Employee JSON is\n"+stringEmp);
    }
}
