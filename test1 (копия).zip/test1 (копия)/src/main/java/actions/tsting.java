package actions;

/**
 * Created by sawa on 09.08.17.
 */
public class tsting {
    public static void main(String[] args) {
        String q="\" asd sd asd asdf \" d";
        String q1[]=q.split(" ");
        System.out.println(q1.length);
    }
}
