package actions;


import java.util.ArrayList;
import java.util.List;

public class Action {
    String text;
    List<Action> actions;

    public Action(String text, List<Action> actions) {
        this.text = text;
        this.actions = actions;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public List<Action> getActions() {
        return actions;
    }

    public void setActions(List<Action> actions) {
        this.actions = actions;
    }

    @Override
    public String toString() {
        return "Action{" +
                "text='" + text + '\'' +
                ", actions=" + actions +
                '}';
    }
}
