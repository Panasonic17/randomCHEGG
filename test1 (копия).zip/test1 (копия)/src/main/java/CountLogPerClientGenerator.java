import java.util.Random;

/**
 * Created by Oleksandr_Shainoga on 8/9/2017.
 */
public class CountLogPerClientGenerator {
    int logCount;
    int clientCount;

    public CountLogPerClientGenerator(int logKount, int clientKount) {
        this.logCount = logKount;
        this.clientCount = clientKount;
    }

    public int[] getKountLogPerClient() {
        Random r = new Random();
        int logPerClient[] = new int[clientCount];
        double e[] = new double[clientCount];
        for (int i = 0; i < clientCount; i++) {
            e[i] = r.nextInt(7) + 20;
        }
        int s = 0;
        for (int i = 0; i < clientCount; i++) {
            s += e[i];
        }
        double koef = (double) logCount / (double) s;
        int total = 0;
        for (int i = 0; i < clientCount; i++) {

            int q = (int) Math.round(e[i] * koef);
            logPerClient[i] = q;
            total += q;
//            System.out.println(q);
        }
//        System.out.println(total);
        return logPerClient;
    }

    public static void main(String[] args) {
        CountLogPerClientGenerator countLogPerClientGenerator = new CountLogPerClientGenerator(1000, 10);
        int a[]=countLogPerClientGenerator.getKountLogPerClient();
        for (int i = 0; i <a.length ; i++) {
            System.out.println(a[i]);
        }
    }
}
