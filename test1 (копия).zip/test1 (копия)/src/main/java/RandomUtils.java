import java.util.Random;

/**
 * Created by Oleksandr_Shainoga on 8/8/2017.
 */
public class RandomUtils {

    public static String getRandomString(){
//        return Long.toString(Math.abs(random.nextLong()), 36);
    return null;
    }

}
