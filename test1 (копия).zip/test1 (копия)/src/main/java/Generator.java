import java.text.SimpleDateFormat;
import java.util.*;

public class Generator {
    int logCount;
    int clientCount;
    long startTime;
    long endTime;
    String template;
    Random r = new Random();

    ArrayList<Long> times = new ArrayList<>();
    long clientStart11[];
    int logPerClient[];
    ArrayList<Long> clientStart;

    public Generator(int logCount, int clientCount, long startTime, long endTime, String template) {
        this.logCount = logCount;
        this.clientCount = clientCount;
        this.startTime = startTime;
        this.endTime = endTime;
        this.template=template;
        TimeGenerator timeGenerator = new TimeGenerator(startTime, endTime, logCount);
        times = timeGenerator.getTimes();
        ClientStartGenerator clientStartGenerator = new ClientStartGenerator(logCount, clientCount);
//        clientStart11 = clientStartGenerator.getClientsLoginTurn();
        clientStart = new ArrayList(Arrays.asList(clientStartGenerator.getClientsLoginTurn()));
        CountLogPerClientGenerator countLogPerClientGenerator = new CountLogPerClientGenerator(logCount, clientCount);
        logPerClient = countLogPerClientGenerator.getKountLogPerClient();


    }

    int logNumber = 0;
    int clientNumber = 0;
    ArrayList<Client> clients = new ArrayList<>();
    SimpleDateFormat sdf = new SimpleDateFormat("[dd/MM/yyyy:HH:mm:ss Z]");

    public String generate() {
        //creating cliens

        if (clients.size() == 0) {
            for (int i = 0; i < 3; i++) {
                Client client = new Client(false, 10);
                clients.add(client);
                clientNumber++;
            }
        }
        if (Math.random() > 0.9) {
            Client client = new Client(false, 10);
            clients.add(client);
//            System.out.println("qqqqqqq "+clients.size()+ " "+ logPerClient[clientNumber]);
            clientNumber++;
        }

//
//        if (clientStart.contains(logNumber)) {
//            Client client = new Client(false, logPerClient[clientNumber]*2);
//            clients.add(client);
////            System.out.println("qqqqqqq "+clients.size()+ " "+ logPerClient[clientNumber]);
//            clientNumber++;
//        }

        //chose client


        Client c = clients.get(r.nextInt(clients.size()));
        Map<String, String> logData = c.doThmth();
//        System.out.println(c);

        if (logData.get("action").equals("logout")) {
            clients.remove(c);
        }
        logNumber++;

//        System.out.println("time =" +times.get(timeIndex));
        String date = sdf.format(times.get(logNumber));
        logData.put("time", date + "");
        return logDataToLog(logData);
    }

    String logDataToLog(Map<String, String> data) {
        String ret = template;
        for (Map.Entry<String, String> entry : data.entrySet()) {
            ret=ret.replace(entry.getKey(),entry.getValue());// += entry.getKey() + "=" + entry.getValue() + " ";
//        ret += entry.getKey() + "=" + entry.getValue();
        }

        return ret;
    }

}
