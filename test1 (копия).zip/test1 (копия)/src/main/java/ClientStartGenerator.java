
public class ClientStartGenerator {
    int logKount;
    int clientKount;
    double clientCreationStep;

    public ClientStartGenerator(int logKount, int clientKount) {
        this.logKount = logKount;
        this.clientKount = clientKount;
        clientCreationStep = logKount / clientKount;
        System.out.println(clientCreationStep);
    }

    public long[] getClientsLoginTurn() {
        long logTurn[] = new long[clientKount];
        logTurn[0]= (long) (clientCreationStep/2);
        for (int i = 1; i < clientKount; i++) {
            if (Math.random() > 0.5)
                logTurn[i] = logTurn[i-1]+ Math.round(clientCreationStep + clientCreationStep *(Math.random()/5));
            else
                logTurn[i] =  logTurn[i-1]+Math.round(clientCreationStep - clientCreationStep *(Math.random()/5));
            System.out.println(logTurn[i]);
        }
        return logTurn;
    }

    public static void main(String[] args) {
        ClientStartGenerator clientStartGenerator = new ClientStartGenerator(1000, 15);
        long a[] = clientStartGenerator.getClientsLoginTurn();
        for (int i = 0; i <a.length ; i++) {
            System.out.println(a[i]);
        }

    }
}
