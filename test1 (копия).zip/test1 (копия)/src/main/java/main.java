import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class main {

    public static void main(String[] args) throws Exception {
//        if(args.length!=8){
//                throw  new Exception("not enought params need 8 params -n -f -s -e");
//        }

        StringBuilder builder = new StringBuilder();
        for (String s : args) {
            builder.append(s + " ");
        }
        String str = builder.toString();
        String inputParams[] = str.split("-");


        Map<String, String> params = new HashMap();
        for (int i = 0; i < inputParams.length; i++) {
            String keyValue[] = inputParams[i].split(" ");
            if (keyValue.length == 2)
                params.put(keyValue[0], keyValue[1]);
            else {
                if (keyValue.length == 1) continue;

                String value = "";
                for (int j = 1; j < keyValue.length; j++) {
                    value += keyValue[j] + " ";
                }

                params.put(keyValue[0], value);
            }
        }
//        System.out.println("number =" + params.get("n"));
//        System.out.println("start =" + params.get("s"));
//        System.out.println("end =" + params.get("f"));
//        System.out.println("template=" + params.get("t"));
//        System.out.println("path"+params.get("p"));

        Date d = new Date();
        Date d1 = new Date(2017 - 1900, 7, 5);
        Generator g = new Generator(10000 + 1, 3, d.getTime(), d1.getTime(), params.get("t"));
//        TestGenerator testGenerator=new TestGenerator(100,d.getTime(),d1.getTime());
//        int n= Integer.parseInt(params.get("n"));
//        try (BufferedWriter bw = new BufferedWriter(new FileWriter(params.get("p")))) {
////
////            String content = "This is the content to write into file\n";
////
////
////            for (int i = 0; i < n; i++) {
////                System.out.println(g.generate());
////                bw.write(g.generate()+"\n");
////            }
////
////
////        } catch (IOException e) {
////
////            e.printStackTrace();
////
////        }
////
//
//
        ArrayList<String> test = new ArrayList<>();
        test.add("q11");
        test.add("q10");
        test.add("q9");
        test.add("q8");
        test.add("q7");
        test.add("q6");
        test.add("q5");
        test.add("q4");
        test.add("q3");
        test.add("q2");
        test.add("q1");
        Client.actionList=test;
        for (int i = 1; i < 10000; i++) {
            System.out.println(g.generate());

        }
    }
}
